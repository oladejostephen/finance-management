<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Paystack Test Secret Key
|--------------------------------------------------------------------------
|
| Copy from Paystack Dashboard
|
*/
$config['paystack_key_test_secret']         = 'sk_test_xxx';


/*
|--------------------------------------------------------------------------
| Paystack Live Secret Key
|--------------------------------------------------------------------------
|
| Copy from Paystack Dashboard
|
*/
$config['paystack_key_live_secret']         = 'sk_live_xxx';

/*
|--------------------------------------------------------------------------
| Paystack Live Secret Key
|--------------------------------------------------------------------------
|
| Copy from Paystack Dashboard
|
*/
$config['paystack_test_mode']               = true;
