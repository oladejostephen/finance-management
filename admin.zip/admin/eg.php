<?php
$db = mysqli_connect('localhost', 'root', '', 'project');
echo $_SESSION['username'];